function Actualizar(){
    let card = document.getElementById("actualizar");
    card.setAttribute("display","block");
}